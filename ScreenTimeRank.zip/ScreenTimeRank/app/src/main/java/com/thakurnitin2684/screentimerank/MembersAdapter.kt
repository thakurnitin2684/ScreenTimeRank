package com.thakurnitin2684.screentimerank

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.userdata_layout.*
import java.util.ArrayList

class MemberViewHolder(v: View) {
    val name: TextView = v.findViewById(R.id.memberName)
    val image: ImageView = v.findViewById(R.id.memberImage)
}

class MembersAdapter(
    context: Context,
    private val resource: Int,
    private val memberName: ArrayList<String>,
    private val imageUrl: ArrayList<String>

) : ArrayAdapter<String>(context, resource) {

    private val inflater = LayoutInflater.from(context)
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {

        val view: View
        val viewHolder: MemberViewHolder

        if (convertView == null) {
            view = inflater.inflate(resource, parent, false)
            viewHolder = MemberViewHolder(view)
            view.tag = viewHolder
        } else {
            view = convertView
            viewHolder = view.tag as MemberViewHolder
        }

         viewHolder.name.text = memberName[position]
        Picasso.get().load(imageUrl[position]).error(R.drawable.common_google_signin_btn_icon_dark_focused)
            .placeholder(R.drawable.common_google_signin_btn_icon_dark_focused).into(viewHolder.image)
        return view
    }

    override fun getCount(): Int {
        return memberName.size
    }

}