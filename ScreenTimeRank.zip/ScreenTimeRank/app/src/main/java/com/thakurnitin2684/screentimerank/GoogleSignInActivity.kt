package com.thakurnitin2684.screentimerank

import android.app.AlertDialog
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.util.Log
import android.view.View
import android.widget.Toast
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.SignInButton
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.android.synthetic.main.activity_google_sign_in.*

private const val TAG = "GoogleActivity"
private const val RC_SIGN_IN = 9001

class GoogleSignInActivity : AppCompatActivity(), View.OnClickListener {
    private var mAuth: FirebaseAuth? = null
    private lateinit var mGoogleSignInClient: GoogleSignInClient
    private lateinit var myDatabase: Database

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_google_sign_in)

        if (!checKPermission()) {
            val builder = AlertDialog.Builder(this)

            builder.setMessage("This app requires your permission for app usage stats.We will not share your data with anybody else")
                .setCancelable(false)
                .setPositiveButton(
                    "Give Permission"
                ) { dialog, id ->
//                    dialog.cancel()
                    startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))

                       this.finishAffinity()

                    Toast.makeText(
                        applicationContext, "you choose yes action for alertbox",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                .setNegativeButton(
                    "Deny"
                ) { dialog, id -> //  Action for 'NO' Button
                    this.finishAffinity()
                    Toast.makeText(
                        applicationContext, "you choose no action for alertbox",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            //Creating dialog box
            //Creating dialog box
            val alert = builder.create()
            //Setting the title manually
            //Setting the title manually
            alert.setTitle("App Permissions")
            alert.show()
        }
            sign_in_button.setOnClickListener(this)
        // Configure Google Sign In
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(R.string.default_web_client_id))
            .requestEmail()
            .build()

        mGoogleSignInClient = GoogleSignIn.getClient(this, gso)

        // Set the dimensions of the sign-in button.
        sign_in_button.setSize(SignInButton.SIZE_WIDE)

        // Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance()
    }

    public override fun onStart() {
        super.onStart()

        // Check if user is signed in (non-null) and update UI accordingly.
        val currentUser = mAuth!!.currentUser

        if (currentUser != null && checKPermission()) {
            Log.d(TAG, "Currently Signed in: " + currentUser.email!!)
//            Toast.makeText(this@GoogleSignInActivity, "Currently Logged in: " + currentUser.email!!, Toast.LENGTH_LONG).show()

            startActivity(Intent(this, MainActivity::class.java))
        }
    }

    override fun onClick(v: View) {
        val i = v.id
        if (i == R.id.sign_in_button) {
            signInToGoogle()
        }
    }

    private fun signInToGoogle() {
        val signInIntent = mGoogleSignInClient.signInIntent
        startActivityForResult(signInIntent, RC_SIGN_IN)
    }

    public override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        // Result returned from launching the Intent from GoogleSignInApi.getSignInIntent(...);
        if (requestCode == RC_SIGN_IN) {
            val task = GoogleSignIn.getSignedInAccountFromIntent(data)
            try {
                // Google Sign In was successful, authenticate with Firebase
                val account = task.getResult(ApiException::class.java)
//                Toast.makeText(this, "Google Sign in Succeeded", Toast.LENGTH_LONG).show()

                firebaseAuthWithGoogle(account!!)
            } catch (e: ApiException) {
                // Google Sign In failed, update UI appropriately
                Log.w(TAG, "Google sign in failed", e)
//                Toast.makeText(this, "Google Sign in Failed $e", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun firebaseAuthWithGoogle(acct: GoogleSignInAccount) {
        Log.d(TAG, "firebaseAuthWithGoogle:" + acct.id!!)

        val credential = GoogleAuthProvider.getCredential(acct.idToken, null)
        mAuth!!.signInWithCredential(credential)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Sign in success, update UI with the signed-in user's information
                    val user = mAuth!!.currentUser
//                    Log.d(TAG, "signInWithCredential:success: currentUser: " + user!!.email!!)

                    myDatabase = Database()
                    myDatabase!!.open()
                    if (acct != null && user != null) {
                            myDatabase.addDbForFirstTime(
                                user.uid,
                                acct.displayName,
                                acct.email,
                                acct.photoUrl.toString()
                            )
                        var intent = Intent(this@GoogleSignInActivity, MainActivity::class.java)
                        intent.putExtra("newBool", "Present")
                        startActivity(intent)

                    }

                } else {
                    Log.w(TAG, "signInWithCredential:failure", task.exception)
                }
            }
    }
    private fun checKPermission(): Boolean {
        val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = appOps.checkOpNoThrow(
            "android:get_usage_stats",
            Process.myUid(), packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }
    override fun onBackPressed() {

    }
}
