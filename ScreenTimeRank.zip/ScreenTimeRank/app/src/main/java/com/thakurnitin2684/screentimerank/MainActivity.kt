package com.thakurnitin2684.screentimerank

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.transition.AutoTransition
import android.transition.TransitionManager
import android.util.DisplayMetrics
import android.util.Log
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import com.clockbyte.admobadapter.AdmobAdapterWrapper
import com.clockbyte.admobadapter.expressads.AdmobExpressAdapterWrapper
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.InterstitialAd
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.dynamiclinks.FirebaseDynamicLinks
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.messaging.FirebaseMessaging
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.userdata_layout.*
import java.security.AccessController.getContext
import java.util.*
import kotlin.collections.ArrayList

private const val TAG = "MainActivity"
private class AppUsageInfo internal constructor(var packageName: String) {
    var appIcon: Drawable? = null
    var appName: String? = null
    var timeInForeground: Long = 0
    var launchCount = 0

}
class MainActivity : AppCompatActivity() {

    private  var myDatabase: FirebaseFirestore?=null
    private var userId:String?=null
    private var mAuth: FirebaseAuth? = null
    private lateinit var mGoogleSignInClient: GoogleSignInClient
    private lateinit var database: Database
 private var alarmHandler = AlarmDatabase(this)
private lateinit var interAd : InterstitialAd
    private  lateinit var adapterWrapper: AdmobAdapterWrapper

    @RequiresApi(Build.VERSION_CODES.LOLLIPOP_MR1)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)






        userId =  FirebaseAuth.getInstance().currentUser?.uid

       alarmHandler.cancelAlarmManager()
        alarmHandler.setAlarmManager()

        MobileAds.initialize(this,"ca-app-pub-9091905143657596~4053741257")
        val adReqst =AdRequest.Builder().build()
        bannerAd.loadAd(adReqst)
        interAd = InterstitialAd(this)
        interAd.adUnitId  = getString(R.string.interAdId)
        intent.extras?.let {
            for (key in it.keySet()){
                val value = intent.extras!!.get(key)
                Log.d(TAG, "key :$key Value :$value ")
            }
        }


        val displayMetrics: DisplayMetrics = this.resources.displayMetrics
        val dpWidth = displayMetrics.widthPixels / displayMetrics.density
//        adapterWrapper = AdmobExpressAdapterWrapper(
//            getContext(),
//            getString(R.string.nativeAdId),
//            AdSize(dpWidth.toInt() - 4, 350)
//        )
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
           val channelId = getString(R.string.default_notification_channel_id)
            val channelName = "Topic"
            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager?.createNotificationChannel(
                NotificationChannel(
                    channelId,
                    channelName,NotificationManager.IMPORTANCE_LOW
                )
            )
        }
        FirebaseMessaging.getInstance().subscribeToTopic("AllTopic")
            .addOnCompleteListener{
//                 Toast.makeText(this, "topic", Toast.LENGTH_SHORT).show()
            }
        var newCheck = intent.getStringExtra("newBool")


        database = Database()
        database.open()
        myDatabase= FirebaseFirestore.getInstance()

        val docRef = myDatabase?.collection("users")?.document(
            userId!!)

        docRef?.addSnapshotListener { documentSnapshot, e ->

            if (e != null) {
                Log.d(TAG, "Listen Failed", e)
                return@addSnapshotListener
            }
            if (documentSnapshot != null && documentSnapshot.exists()) {
                val user = documentSnapshot.toObject(User::class.java)
                if (user != null) {
                    Log.d(
                        TAG,
                        "${user.name}  ${user.email}  ${user.url} ${user.screenTime} ${user.rooms}"
                    )
                    nameText.text =user.name
                    emailText.text=user.email
                    Picasso.get().load(user.url).error(R.drawable.common_google_signin_btn_icon_dark_focused)
                    .placeholder(R.drawable.common_google_signin_btn_icon_dark_focused).into(imageUrlText)
//                    screenTimeText.text=user.screenTime.toString()
                  val data : MutableList<RoomData> = MutableList(user.rooms.size) { RoomData()}
                 val dataAdapter = userId?.let {
                     UserDataAdapter(this, R.layout.each_room, user.rooms,user.screenTime,
                         it,
                         data
                     )
                 }
                    adapterWrapper.adapter = dataAdapter;
                    adapterWrapper.limitOfAds = 10;
                    adapterWrapper.noOfDataBetweenAds = 6;
                    adapterWrapper.firstAdIndex = 2;

                 mainListView.adapter=adapterWrapper
              }
            }
        }
        val inflater = LayoutInflater.from(this)
        val headerView = inflater.inflate(R.layout.userdata_layout, mainListView, false)
        mainListView.addHeaderView(headerView)

        expandMainButton.setOnClickListener{
            if(detailsText.visibility== View.GONE){
                TransitionManager.beginDelayedTransition(
                    mainListView,
                    AutoTransition()
                )
                detailsText.visibility=View.VISIBLE
                expandMainButton.setBackgroundResource(R.drawable.arrow_up)
            }else{
                TransitionManager.beginDelayedTransition(
                    mainListView,
                    AutoTransition()
                )
                detailsText.visibility=View.GONE
                expandMainButton.setBackgroundResource(R.drawable.arrow_down)
            }
        }
         //Screen Time code
        var cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY,0)
        cal.set(Calendar.MINUTE,0)
        cal.set(Calendar.SECOND,1)
        val endTime = System.currentTimeMillis()
        val startTime = cal.timeInMillis
        var currentEvent: UsageEvents.Event
        val allEvents: MutableList<UsageEvents.Event> = ArrayList()
        val map = HashMap<String, AppUsageInfo?>()

        val mUsageStatsManager =
            getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val usageEvents =
            mUsageStatsManager.queryEvents(startTime, endTime)
        while (usageEvents.hasNextEvent()) {
            currentEvent = UsageEvents.Event()
            usageEvents.getNextEvent(currentEvent)
            if (currentEvent.eventType == UsageEvents.Event.ACTIVITY_RESUMED ||
                currentEvent.eventType == UsageEvents.Event.ACTIVITY_PAUSED
            ) {
                allEvents.add(currentEvent)
                val key = currentEvent.packageName
                if (map[key] == null) map[key] = AppUsageInfo(key)
            }
        }
        for (i in 0 until allEvents.size - 1) {
            val event1 = allEvents[i]
            val event2 = allEvents[i + 1]
            if (event1.packageName != event2.packageName && event2.eventType == 1) {
                map[event2.packageName]!!.launchCount++
            }
            if (event1.eventType == 1 && event2.eventType == 2 && event1.className == event2.className
            ) {
                val diff = event2.timeStamp - event1.timeStamp
                map[event1.packageName]!!.timeInForeground += diff
            }
        }
        var smallInfoList :MutableList<AppUsageInfo?> =ArrayList()
        var appsArray : ArrayList<String> = ArrayList()
        var appsArrayTime : ArrayList<String> = ArrayList()
        var appsArrayTimeSort : ArrayList<Long> = ArrayList()

        smallInfoList.addAll(map.values)
        var totalTime :Long=0
        var showString="\n"
        for (appUsageInfo in smallInfoList) {
            if (appUsageInfo != null) {

                showString += (getAppNameFromPackage (appUsageInfo.packageName) + " : " + appUsageInfo.timeInForeground/60000 + "\n")
                totalTime+=appUsageInfo.timeInForeground
                appsArray.add(appUsageInfo.packageName)
                appsArrayTimeSort.add(appUsageInfo.timeInForeground/60000)
                val hour = appUsageInfo.timeInForeground/ 3600000
                val min =(appUsageInfo.timeInForeground/60000)%60

                if (hour ==0.toLong() && min !=0.toLong()){
                    val time = min.toString()+"m"
                    appsArrayTime.add(time)
                }else if (hour ==0.toLong() && min ==0.toLong()){
                    val time = "<1m"
                    appsArrayTime.add(time)
                }else {
                    val time = hour.toString() + "h: " + min + "m"
                    appsArrayTime.add(time)
                }
            }
        }
        for( i in 0 until  appsArrayTimeSort.size){
            for (j in i until appsArrayTimeSort.size){
                   if(appsArrayTimeSort[i]<appsArrayTimeSort[j]){
                       val temp = appsArrayTimeSort[i]
                       val temp3 = appsArrayTime[i]
                       val temp2 =appsArray[i]
                       appsArray[i]=appsArray[j]
                       appsArrayTimeSort[i]=appsArrayTimeSort[j]
                       appsArrayTime[i]=appsArrayTime[j]
                       appsArray[j]=temp2
                       appsArrayTimeSort[j]=temp
                       appsArrayTime[j]=temp3

                   }
            }
            Log.d(TAG,"Time loop ${appsArrayTime[i]}")
        }
        if(newCheck !=null){
        database.updateTime(userId,totalTime )

        }
        Log.d(TAG," Time : $showString")
        val hour = totalTime/ 3600000
        val min =(totalTime/60000)%60
        if (hour ==0.toLong()){
            screenTimeText.text = min.toString()+"m"

        }else if (hour ==0.toLong() && min ==0.toLong()){
            screenTimeText.text = "<1m"
        }else {
            screenTimeText.text = hour.toString() + "h: " + min + "m"
        }
        Log.d(TAG," TotalTime : ${screenTimeText.text}")

        //End of Screen Time Code
        timeCard.setOnClickListener{
            val bundleUsage = Bundle()
            bundleUsage.putString("totalTime",screenTimeText.text as String)
            bundleUsage.putStringArrayList("apps",appsArray)
            bundleUsage.putStringArrayList("appsTime",appsArrayTime)



            val fragment = UsageStatsFragment()
            fragment.arguments = bundleUsage

            for (fragment in supportFragmentManager.fragments) {
                if (fragment != null)
                    supportFragmentManager.beginTransaction().remove(fragment).commit()
            }
            supportFragmentManager.beginTransaction().add(R.id.mainContainter, fragment).commit()
            supportActionBar?.setDisplayHomeAsUpEnabled(true)
        }
        requestInterAd()
        mainListView.setOnItemClickListener { parent, _, position, _ ->
            if (position != 0) {
                if(interAd.isLoaded){
                    interAd.show()


                }
                requestInterAd()
                val element = parent.getItemAtPosition(position) as RoomData
                Log.d(TAG, "RoomData: ${element.rank} ${element.roomId} ${element.membersName}")

                val bundle = Bundle()
                bundle.putString("userId",userId)
                bundle.putString("roomName",element.roomName)
                bundle.putString("roomId",element.roomId)
                bundle.putString("rank",element.rank)
                bundle.putStringArrayList("members",element.members)
                bundle.putStringArrayList("membersName",element.membersName)
                bundle.putStringArrayList("membersUrl",element.membersUrl)


                val fragment = RoomFragment()
                fragment.arguments = bundle

                for (fragment in supportFragmentManager.fragments) {
                    if (fragment != null)
                        supportFragmentManager.beginTransaction().remove(fragment).commit()
                }
                supportFragmentManager.beginTransaction().add(R.id.mainContainter, fragment).commit()
                supportActionBar?.setDisplayHomeAsUpEnabled(true)

            }else{
//                startActivity(Intent(Settings.ACTION_APP_USAGE_SETTINGS))

            }
        }
        // Configure Google Sign In
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            // for the requestIdToken, use getString(R.string.default_web_client_id), this is in the values.xml file that
            // is generated from your google-services.json file (data from your firebase project), uses the google-sign-in method
            // web api key
            .requestIdToken(getString(R.string.default_web_client_id))
            .requestEmail()
            .build()

        // Build a GoogleSignInClient with the options specified by gso.
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso)

        mAuth = FirebaseAuth.getInstance()

        FirebaseDynamicLinks.getInstance()
            .getDynamicLink(intent)
            .addOnSuccessListener(this) { pendingDynamicLinkData ->
                var deeplink: Uri? = null
                if (pendingDynamicLinkData != null) {
                    deeplink = pendingDynamicLinkData.link
                }
                if (deeplink != null) {
                    val id = deeplink.getQueryParameter("data")
                    Toast.makeText(applicationContext, "New Room Added", Toast.LENGTH_SHORT)
                        .show()
                    if (id != null) {
                        database.addForRoom(userId, id)
                    }
                }
            }
    }
    private fun requestInterAd(){
        val iadRqst = AdRequest.Builder().build()
        interAd.loadAd(iadRqst)
    }
    private fun getAppNameFromPackage(
        packageName: String
    ): String? {

        val pm: PackageManager = applicationContext.packageManager
        val ai: ApplicationInfo?
        ai = try {
            pm.getApplicationInfo(packageName, 0)
        } catch (e: PackageManager.NameNotFoundException) {
            null
        }
        val applicationName =
            (if (ai != null) pm.getApplicationLabel(ai) else "(unknown)")
        return applicationName.toString()
    }
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.signOut -> signOut()
            R.id.createRoom-> {
                createRoomFragment()
                supportActionBar?.setDisplayHomeAsUpEnabled(true)
            }
            android.R.id.home -> {
               removeAllFragments()
            }
        }
        return super.onOptionsItemSelected(item)
    }
    private fun createRoomFragment(){
        for (fragment in supportFragmentManager.fragments) {
            if (fragment != null)
                supportFragmentManager.beginTransaction().remove(fragment).commit()
        }
         val fragment = CreateRoomFragment()
        supportFragmentManager.beginTransaction().add(R.id.mainContainter, fragment).commit()
    }
    private fun signOut() {
        // Firebase sign out
        mAuth!!.signOut()

        // Google sign out
        mGoogleSignInClient.signOut().addOnCompleteListener(this) {
            // Google Sign In failed, update UI appropriately
            Log.w("MainActivity", "Signed out of google")

        }
        startActivity(Intent(this, GoogleSignInActivity::class.java))
    }
    override fun onBackPressed() {
                removeAllFragments()
    }
    fun removeAllFragments(){

        for (fragment in supportFragmentManager.fragments) {
            if (fragment != null)
                supportFragmentManager.beginTransaction().remove(fragment).commit()
        }
        supportActionBar?.setDisplayHomeAsUpEnabled(false)
    }
//    override fun onDestroy() {
//        super.onDestroy()
//        adapterWrapper.release()
//    }

}
