package com.thakurnitin2684.screentimerank

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ProgressBar
import android.widget.TextView
import com.google.firebase.firestore.FirebaseFirestore

private const val TAG = "UserDataAdap"


class RoomData {
    lateinit var roomId: String
    lateinit var roomName: String
    lateinit var rank: String
    lateinit var members: ArrayList<String>
    var membersName: ArrayList<String> = ArrayList()
    var membersUrl: ArrayList<String> = ArrayList()
}

class ViewHolder(v: View) {
    val name: TextView = v.findViewById(R.id.roomName)
    val rank: TextView = v.findViewById(R.id.rank)
    val progresB: ProgressBar = v.findViewById(R.id.progressBar)
    val outOfVar: TextView = v.findViewById(R.id.outOf)
//    val delete: Button = v.findViewById(R.id.delButton)

}

class UserDataAdapter(
    context: Context,
    private val resource: Int,
    private val rooms: ArrayList<String>,
    private val screenTime: Long,
    private val userId: String,
    private val data : MutableList<RoomData>
) : ArrayAdapter<RoomData>(context, resource) {
//    private lateinit var members: ArrayList<String>
//    private var membersName: MutableList<String> = ArrayList()
//    private var membersUrl: MutableList<String> = ArrayList()
//    private lateinit var rank: String



    private var myDatabase: FirebaseFirestore? = null
    private lateinit var database: Database
    private val inflater = LayoutInflater.from(context)
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {

        val view: View
        val viewHolder: ViewHolder

        if (convertView == null) {
            view = inflater.inflate(resource, parent, false)
            viewHolder = ViewHolder(view)
            view.tag = viewHolder
        } else {
            view = convertView
            viewHolder = view.tag as ViewHolder
        }


        val currentRoom = rooms[position]
        data[position].roomId = rooms[position]
        myDatabase = FirebaseFirestore.getInstance()
        val docRef = myDatabase?.collection("rooms")?.document(
            currentRoom
        )
        val screenTList: MutableList<Long> = ArrayList()
        val docRef2 = myDatabase?.collection("users")


        docRef?.get()?.addOnSuccessListener { documentSnapshot ->


            Log.d(TAG,"Current Room Id :$currentRoom  Started" )


                data[position].roomName = (documentSnapshot.get("name")).toString()
                viewHolder.name.text =    data[position].roomName
                data[position].members = documentSnapshot.get("members") as ArrayList<String>


            for (i in 0 until data[position].members.size) {
                val eachRef = docRef2?.document(data[position].members[i])
                eachRef?.get()?.addOnSuccessListener { documentSnapshot ->


                        screenTList.add(documentSnapshot.get("screenTime") as Long)
                        data[position].membersName.add(documentSnapshot.get("name") as String)
                        data[position].membersUrl.add(documentSnapshot.get("url") as String)
                        Log.d(TAG,"Screen Time list : $screenTList  at i : $i")

                    if (screenTList.size == data[position].members.size ) {

                        screenTList.sort()
//                        screenTList.reverse()
                        data[position].rank = (screenTList.binarySearch(screenTime) + 1).toString()
                        viewHolder.rank.text = data[position].rank
                        viewHolder.outOfVar.text = "out of " + data[position].members.size.toString()

                        Log.d(TAG, "List:${screenTList}")
                        Log.d(TAG, "rank:${screenTList.binarySearch(screenTime)}")
                        viewHolder.progresB.visibility = View.GONE
                    }
                }?.addOnFailureListener {
                    Log.d(TAG, "User:")
                }
            }
//            Log.d(TAG, "Members: $data.members")
            Log.d(TAG,"Current Room Id :$currentRoom  Ended" )

        }?.addOnFailureListener {
            Log.d(TAG, "User:")
        }

        return view
    }

    override fun getCount(): Int {
        return rooms.size
    }

    override fun getItem(position: Int): RoomData? {
        return data[position]
    }

}
