package com.thakurnitin2684.screentimerank

import android.util.Log
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

private const val TAG= "AlarmService"
class MyFirebaseMessagingService : FirebaseMessagingService() {

    override fun onMessageReceived(p0: RemoteMessage) {
        Log.d(TAG,"Message is  ")

        p0.data?.isNotEmpty()?.let {
            Log.d(TAG,"Message is :${p0.data} ")
        }
    }
}
