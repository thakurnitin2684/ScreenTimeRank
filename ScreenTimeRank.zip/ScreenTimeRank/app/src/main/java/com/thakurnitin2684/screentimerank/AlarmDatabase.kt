package com.thakurnitin2684.screentimerank

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.util.Log
import android.widget.Toast
import java.util.*

private const val TAG="AlarmDatabase"
class AlarmDatabase(var context: Context) {

    fun setAlarmManager() {
        val intent = Intent(context, MyReceiver::class.java)

        val pendingIntent = PendingIntent.getBroadcast(
            context, 2, intent, 0
        )
        val alarmManager =
            context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager
        if (alarmManager != null) {
            var triggerEvery: Long = 60 * 1000*60
            var cal = Calendar.getInstance()
            var cal2 = Calendar.getInstance()

            cal.add(Calendar.HOUR, 1)
            cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0)
            var triggerAfter = cal.timeInMillis
             Log.d(TAG,"Trigger First Time : ${cal.time}")
            Log.d(TAG," Time Now : ${cal2.time}")
            Log.d(TAG,"Trigger After : ${triggerAfter/1000}")
            Log.d(TAG,"Trigger Every : ${triggerEvery/1000}")


            alarmManager.setRepeating(
                AlarmManager.RTC_WAKEUP,
                triggerAfter,
                triggerEvery,
                pendingIntent
            )
        }
    }

    fun cancelAlarmManager() {
        val intent = Intent(context, MyReceiver::class.java)

        val pendingIntent = PendingIntent.getBroadcast(
            context, 2, intent, 0
        )
        val alarmManager =
            context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager
        if (alarmManager != null) {
            alarmManager.cancel(pendingIntent)
        }

    }
}