package com.thakurnitin2684.screentimerank

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.util.Log
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import java.util.*

private const val TAG="MyReceiver"
class MyReceiver : BroadcastReceiver() {
    var database = Database()
    private var userId:String?=null


    override fun onReceive(context: Context?, intent: Intent?) {
        if (intent != null) {
            if(intent.action.equals(Intent.ACTION_BOOT_COMPLETED)){
                val alarmHandler = context?.let { AlarmDatabase(it) }
                alarmHandler?.cancelAlarmManager()
                alarmHandler?.setAlarmManager()
            }
        }
        userId =  FirebaseAuth.getInstance().currentUser?.uid

        database.open()
        var cal = Calendar.getInstance()
        database.testMethod(userId,cal.time.toString())
        Log.d(TAG,"at: ${cal.time}")
        Toast.makeText(context,"Receiver here",Toast.LENGTH_SHORT).show()

     }

}